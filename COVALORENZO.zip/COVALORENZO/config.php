<?php
$servername = "localhost"; 
$username = "root";
$password = "";         
$dbname = "COVALORENZO";   

require 'ControlloConfig.php';
?>

