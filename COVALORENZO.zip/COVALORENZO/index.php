<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage - Gestione Rappresentanti</title>
</head>
<body>
    <h1>Gestione Rappresentanti Aziendali</h1>
    <ul>
        <li><a href="primaFunzione.php">Cerca rappresentante in base al fatturato</a></li>
        <li><a href="secondaFunzione.php">Controlla e aumenta provvigioni</a></li>
        <li><a href="terzaFunzione.php">Aggiungi Rappresentante</a></li>
        <li><a href="quartaFunzione.php">Elimina rappresentante</a></li>
        <li><a href="quintaFunzione.php">Visualizza rappresentanti</a></li>
    </ul>
</body>
</html>
